import React, { useState } from 'react';
import { Users, Heart, Clock, TrendingUp, Search, Filter, Eye } from 'lucide-react';

const DoctorDashboard: React.FC = () => {
  const [selectedTab, setSelectedTab] = useState('patients');
  const [searchTerm, setSearchTerm] = useState('');

  const patients = [
    {
      id: 1,
      name: 'Rahul Sharma',
      age: 25,
      bloodType: 'B+',
      lastTransfusion: '2024-12-15',
      nextDue: '2025-01-15',
      status: 'Due Soon',
      hemoglobin: '7.2 g/dL',
      phone: '+91 98765 43210'
    },
    {
      id: 2,
      name: 'Priya Patel',
      age: 18,
      bloodType: 'A+',
      lastTransfusion: '2024-12-28',
      nextDue: '2025-01-28',
      status: 'Stable',
      hemoglobin: '8.1 g/dL',
      phone: '+91 87654 32109'
    },
    {
      id: 3,
      name: 'Arjun Kumar',
      age: 32,
      bloodType: 'O+',
      lastTransfusion: '2025-01-01',
      nextDue: '2025-02-01',
      status: 'Critical',
      hemoglobin: '6.8 g/dL',
      phone: '+91 76543 21098'
    }
  ];

  const bloodRequests = [
    {
      id: 1,
      patientName: 'Rahul Sharma',
      bloodType: 'B+',
      units: 2,
      urgency: 'Critical',
      hospital: 'AIIMS Delhi',
      requestedAt: '2 hours ago',
      availableDonors: 7
    },
    {
      id: 2,
      patientName: 'Sneha Gupta',
      bloodType: 'A+',
      units: 1,
      urgency: 'High',
      hospital: 'Fortis Hospital',
      requestedAt: '5 hours ago',
      availableDonors: 12
    }
  ];

  const stats = [
    { label: 'Active Patients', value: '156', icon: Users, color: 'bg-blue-600' },
    { label: 'Pending Requests', value: '8', icon: Heart, color: 'bg-red-600' },
    { label: 'This Month Transfusions', value: '47', icon: TrendingUp, color: 'bg-green-600' },
    { label: 'Avg Response Time', value: '2.4h', icon: Clock, color: 'bg-purple-600' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Critical': return 'bg-red-100 text-red-800';
      case 'Due Soon': return 'bg-orange-100 text-orange-800';
      case 'Stable': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'High': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Moderate': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-green-100 text-green-800 border-green-200';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Doctor Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage your Thalassemia patients and blood requests</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'patients', label: 'My Patients', count: patients.length },
                { id: 'requests', label: 'Blood Requests', count: bloodRequests.length },
                { id: 'analytics', label: 'Analytics', count: null }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    selectedTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                  {tab.count !== null && (
                    <span className={`ml-2 px-2 py-1 rounded-full text-xs ${
                      selectedTab === tab.id ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                    }`}>
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Search and Filter */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search patients or requests..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                />
              </div>
              <button className="flex items-center space-x-2 px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Filter className="h-5 w-5 text-gray-500" />
                <span>Filter</span>
              </button>
            </div>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {selectedTab === 'patients' && (
              <div className="space-y-4">
                {patients.map((patient) => (
                  <div key={patient.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">{patient.name}</h3>
                          <span className="text-sm text-gray-600">({patient.age} years)</span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(patient.status)}`}>
                            {patient.status}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Blood Type:</span>
                            <p className="font-medium text-red-600">{patient.bloodType}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Hemoglobin:</span>
                            <p className="font-medium">{patient.hemoglobin}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Last Transfusion:</span>
                            <p className="font-medium">{patient.lastTransfusion}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Next Due:</span>
                            <p className="font-medium">{patient.nextDue}</p>
                          </div>
                        </div>
                      </div>
                      <button className="ml-4 text-blue-600 hover:text-blue-700">
                        <Eye className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {selectedTab === 'requests' && (
              <div className="space-y-4">
                {bloodRequests.map((request) => (
                  <div key={request.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{request.patientName}</h3>
                        <p className="text-sm text-gray-600">{request.hospital}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getUrgencyColor(request.urgency)}`}>
                        {request.urgency}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                      <div>
                        <span className="text-gray-500">Blood Type:</span>
                        <p className="font-medium text-red-600">{request.bloodType}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Units Needed:</span>
                        <p className="font-medium">{request.units}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Available Donors:</span>
                        <p className="font-medium text-green-600">{request.availableDonors}</p>
                      </div>
                      <div>
                        <span className="text-gray-500">Requested:</span>
                        <p className="font-medium">{request.requestedAt}</p>
                      </div>
                    </div>
                    <div className="flex space-x-3">
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        Contact Donors
                      </button>
                      <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                        View Details
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {selectedTab === 'analytics' && (
              <div className="text-center py-12">
                <TrendingUp className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Analytics Coming Soon</h3>
                <p className="text-gray-600">
                  Comprehensive analytics and reporting features will be available soon.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorDashboard;