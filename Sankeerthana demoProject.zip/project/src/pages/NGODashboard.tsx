import React, { useState } from 'react';
import { Users, Activity, MapPin, Calendar, Plus, Phone, Mail } from 'lucide-react';

const NGODashboard: React.FC = () => {
  const [selectedTab, setSelectedTab] = useState('overview');

  const campaigns = [
    {
      id: 1,
      title: 'World Thalassemia Day 2025',
      date: '2025-05-08',
      location: 'Delhi',
      participants: 245,
      bloodCollected: 89,
      status: 'Upcoming'
    },
    {
      id: 2,
      title: 'Community Blood Drive',
      date: '2025-01-15',
      location: 'Mumbai',
      participants: 156,
      bloodCollected: 67,
      status: 'Active'
    }
  ];

  const volunteers = [
    {
      id: 1,
      name: 'Anjali Desai',
      role: 'Campaign Coordinator',
      location: 'Mumbai',
      joinedDate: '2023-03-15',
      activeCampaigns: 3
    },
    {
      id: 2,
      name: 'Rohit Singh',
      role: 'Medical Volunteer',
      location: 'Delhi',
      joinedDate: '2023-07-22',
      activeCampaigns: 2
    }
  ];

  const stats = [
    { label: 'Active Campaigns', value: '12', icon: Activity, color: 'bg-blue-600' },
    { label: 'Registered Volunteers', value: '234', icon: Users, color: 'bg-green-600' },
    { label: 'Patients Helped', value: '1,840', icon: Users, color: 'bg-purple-600' },
    { label: 'Blood Units Facilitated', value: '3,280', icon: Activity, color: 'bg-red-600' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">NGO Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage campaigns, volunteers, and community outreach</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center">
                <div className={`${stat.color} p-3 rounded-lg`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
                <div className="ml-4">
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Tab Navigation */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'campaigns', label: 'Campaigns' },
                { id: 'volunteers', label: 'Volunteers' },
                { id: 'reports', label: 'Reports' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setSelectedTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    selectedTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {selectedTab === 'overview' && (
              <div className="grid lg:grid-cols-2 gap-8">
                {/* Recent Campaigns */}
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-lg font-semibold text-gray-900">Recent Campaigns</h2>
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                      <Plus className="h-4 w-4" />
                      <span>New Campaign</span>
                    </button>
                  </div>
                  <div className="space-y-4">
                    {campaigns.slice(0, 3).map((campaign) => (
                      <div key={campaign.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="font-medium text-gray-900">{campaign.title}</h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            campaign.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {campaign.status}
                          </span>
                        </div>
                        <div className="text-sm text-gray-600 space-y-1">
                          <p className="flex items-center"><Calendar className="h-4 w-4 mr-1" />{campaign.date}</p>
                          <p className="flex items-center"><MapPin className="h-4 w-4 mr-1" />{campaign.location}</p>
                          <p>{campaign.participants} participants • {campaign.bloodCollected} units collected</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Actions */}
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
                  <div className="space-y-3">
                    <button className="w-full text-left p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="bg-red-100 p-2 rounded-full">
                          <Plus className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">Create Blood Drive</h3>
                          <p className="text-sm text-gray-600">Organize a new blood donation campaign</p>
                        </div>
                      </div>
                    </button>
                    
                    <button className="w-full text-left p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="bg-blue-100 p-2 rounded-full">
                          <Users className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">Recruit Volunteers</h3>
                          <p className="text-sm text-gray-600">Add new volunteers to your team</p>
                        </div>
                      </div>
                    </button>
                    
                    <button className="w-full text-left p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="bg-green-100 p-2 rounded-full">
                          <Calendar className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">Schedule Awareness Program</h3>
                          <p className="text-sm text-gray-600">Plan educational events for community</p>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {selectedTab === 'campaigns' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-semibold text-gray-900">All Campaigns</h2>
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>New Campaign</span>
                  </button>
                </div>
                {campaigns.map((campaign) => (
                  <div key={campaign.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{campaign.title}</h3>
                        <p className="text-gray-600 flex items-center mt-1">
                          <MapPin className="h-4 w-4 mr-1" />
                          {campaign.location}
                        </p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                        campaign.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {campaign.status}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center mb-4">
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-2xl font-bold text-gray-900">{campaign.participants}</p>
                        <p className="text-sm text-gray-600">Participants</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-2xl font-bold text-red-600">{campaign.bloodCollected}</p>
                        <p className="text-sm text-gray-600">Units Collected</p>
                      </div>
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-lg font-bold text-gray-900">{campaign.date}</p>
                        <p className="text-sm text-gray-600">Date</p>
                      </div>
                    </div>
                    <div className="flex space-x-3">
                      <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        Manage
                      </button>
                      <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
                        View Report
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {selectedTab === 'volunteers' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-semibold text-gray-900">Volunteer Team</h2>
                  <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2">
                    <Plus className="h-4 w-4" />
                    <span>Add Volunteer</span>
                  </button>
                </div>
                {volunteers.map((volunteer) => (
                  <div key={volunteer.id} className="border border-gray-200 rounded-lg p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900">{volunteer.name}</h3>
                        <p className="text-blue-600 font-medium">{volunteer.role}</p>
                        <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-500">Location:</span>
                            <p className="font-medium">{volunteer.location}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Joined:</span>
                            <p className="font-medium">{volunteer.joinedDate}</p>
                          </div>
                          <div>
                            <span className="text-gray-500">Active Campaigns:</span>
                            <p className="font-medium text-green-600">{volunteer.activeCampaigns}</p>
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                          <Phone className="h-5 w-5" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-blue-600 transition-colors">
                          <Mail className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {selectedTab === 'reports' && (
              <div className="text-center py-12">
                <Activity className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Reports & Analytics</h3>
                <p className="text-gray-600">
                  Detailed reports and impact analytics will be available soon.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default NGODashboard;